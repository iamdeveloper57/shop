// document.querySelector(".card").addEventListener('click', ()=>{
//     document.querySelector(".card-body").style.display = "block";
//     document.querySelector(".post").style.display = "none";
// })